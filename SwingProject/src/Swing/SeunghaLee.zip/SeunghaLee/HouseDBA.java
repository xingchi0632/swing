package Swing.SeunghaLee;

import java.nio.channels.SelectionKey;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class HouseDBA {
	
String url,user,pwd;
	
	public HouseDBA() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			url="jdbc:oracle:thin:@localhost:1521:xe";
			user="scott";
			pwd="TIGER";
			} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void Join(HouseBean h) {
		Connection con=null;
		
		PreparedStatement ps=null;
		try {
			con=DriverManager.getConnection(url,user,pwd);
			String sql="insert into loginmember values(LOGINMEM"
					+ "BER_SEQ.nextval,?,?,?,?,?,?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setString(1, h.getId());
			ps.setString(2, h.getPw());
			ps.setString(3, h.getName());
			ps.setString(4, h.getBirth());
			ps.setString(5, h.getPhone());
			ps.setString(6, h.getStorename());
			ps.setString(7, h.getStoreaddr());	
			ps.setString(8, h.getLicensenum());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null)ps.close();
				if(con!=null)con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}

		
	}
	
	public ArrayList<HouseBean> Viewall() {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ArrayList<HouseBean> arr=new ArrayList<>();
	try {
	con=DriverManager.getConnection(url, user, pwd);
	String sql="select * from House";
	st=con.createStatement();
	rs=st.executeQuery(sql);
	while(rs.next()) {
		HouseBean h=new HouseBean();
		h.setHnum(rs.getInt("num"));
		h.setTfday(rs.getString("day"));
		h.setTfsi(rs.getString("si"));
		h.setTfgu(rs.getString("gu"));
		h.setTfdong(rs.getString("dong"));
		h.setTfaddr(rs.getString("addr"));			
		h.setTftype(rs.getString("type"));		
		h.setCbhyung(rs.getString("type2"));
		h.setTfprice(rs.getInt("price"));
		h.setTfwol(rs.getString("wol"));
		h.setCbtype(rs.getString("builtype"));
		h.setCbtype2(rs.getString("buil"));			
		h.setTfname(rs.getString("Name"));				
		h.setTfphone(rs.getString("phone"));			
		h.setEtc(rs.getString("etc"));
		h.setCbnow(rs.getString("now"));
		arr.add(h);
	}
} catch (SQLException e) {
	e.printStackTrace();
}finally {
	try {
		if(rs!=null)rs.close();
		if(st!=null)st.close();
		if(con!=null)con.close();
	}catch(SQLException e) {
		e.printStackTrace();
	}
}
return arr;

}
	
public void HouseInsert(HouseBean h) {
	Connection con=null;
	PreparedStatement ps=null;
	try {
		con=DriverManager.getConnection(url,user,pwd);
		String sql="insert into house values(FRIEND_SEQ.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		ps=con.prepareStatement(sql);
		ps.setString(1, h.getTfday());
		ps.setString(2, h.getTfsi());
		ps.setString(3, h.getTfgu());
		ps.setString(4, h.getTfdong());
		ps.setString(5, h.getTfaddr());
		ps.setString(6, h.getTftype());
		ps.setInt(7, h.getTfprice());
		ps.setString(8, h.getTfwol());		
		ps.setString(9, h.getCbtype()+"");
		ps.setString(10, h.getCbtype2()+"");
		ps.setString(11, h.getTfname());
		ps.setString(12, h.getTfphone());
		ps.setString(13, h.getEtc());		
		ps.setString(14, h.getCbhyung()+"");	
		ps.setString(15, h.getCbnow()+"");
		ps.executeUpdate();   
	} catch (SQLException e) {
		e.printStackTrace();
	}finally {
		try {
			if(ps!=null)ps.close();
			if(con!=null)con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	
}


public void HouseDelete(int row) {
	Connection con=null;
	Statement st=null;
	try {
		con=DriverManager.getConnection(url,user,pwd);
		String sql="delete from house where num="+row;
		st=con.createStatement();
		st.executeQuery(sql);
	} catch (SQLException e) {
			e.printStackTrace();
	}finally {
		try {
			if(st!=null)st.close();
			if(con!=null)con.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
public void HouseRE(HouseBean h,int row) {
	Connection con=null;
	Statement st=null;
	PreparedStatement ps=null;
	try {
		con=DriverManager.getConnection(url, user, pwd);
		String sql="update house set day=?,si=?,gu=?,dong=?,addr=?,type=?,price=?,wol=?, builtype=?,buil=?,name=?,phone=?,etc=?,type2=?,now=? where num=?";
		ps=con.prepareStatement(sql);
		
		ps.setString(1, h.getTfday());  //1
		//System.out.println(h.getTfday());		
		
		ps.setString(2, h.getTfsi()); //2
		//System.out.println(h.getTfsi());		
		
		ps.setString(3, h.getTfgu()); //3
		//System.out.println(h.getTfgu());
		
		ps.setString(4, h.getTfdong()); //4
		//System.out.println(h.getTfdong());
		
		ps.setString(5, h.getTfaddr());	 //5
		//System.out.println(h.getTfaddr());
		
		ps.setString(6, h.getTftype()); //6
		//System.out.println(h.getTftype());

		ps.setInt(7, h.getTfprice()); //10
		//System.out.println(h.getTfprice());
		
		ps.setString(8, h.getCbhyung());	//7
		//System.out.println(h.getCbhyung());

		ps.setString(9, h.getCbtype()); //8
		//System.out.println(h.getCbtype());

		ps.setString(10, h.getCbtype2());  //9
		//System.out.println(h.getCbtype2());
		

		
		ps.setString(11, h.getTfwol()); //11
		//System.out.println(h.getTfwol());
		

		
		ps.setString(12, h.getTfname()); //12
		//System.out.println(h.getTfname());
		
		ps.setString(13, h.getTfphone()); //13
		//System.out.println(h.getTfphone());
		
		ps.setString(14, h.getEtc()); //14
		//System.out.println(h.getEtc());
		

		
		ps.setString(15, h.getCbnow());		 //15
		//System.out.println(h.getCbnow());
		
		ps.setInt(16,row);  //16
		//System.out.println(row);
		
		ps.executeUpdate();
	} catch (SQLException e) {
		e.printStackTrace();
	}finally {
		try {
			if(ps!=null)ps.close();
			if(con!=null)con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
}

		
	

