package Swing.SeunghaLee;

public class HouseBean {
	private int num;
	private String id;
	private String pw;
	private String name;
	private String birth;
	private String phone;
	private String storename;
	private String storeaddr;
	private String licensenum;
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getStorename() {
		return storename;
	}
	public void setStorename(String storename) {
		this.storename = storename;
	}
	public String getStoreaddr() {
		return storeaddr;
	}
	public void setStoreaddr(String storeaddr) {
		this.storeaddr = storeaddr;
	}
	public String getLicensenum() {
		return licensenum;
	}
	public void setLicensenum(String licensenum) {
		this.licensenum = licensenum;
	}
	
	private int hnum;
	private String tfday;
	private String tfsi;
	private String tfgu;
	private String tfdong;
	private String tfaddr;
	private String tftype;
	private String cbhyung;
	private String cbtype;
	private String cbtype2;
	private int tfprice;
	private String tfwol;
	private String tfname;
	private String tfphone;	
	private String etc;
	private String cbnow;
	
	
	public String getCbnow() {
		return cbnow;
	}
	public void setCbnow(String cbnow) {
		this.cbnow = cbnow;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
	public int getHnum() {
		return hnum;
	}
	public void setHnum(int hnum) {
		this.hnum = hnum;
	}
	public String getTfday() {
		return tfday;
	}
	public void setTfday(String tfday) {
		this.tfday = tfday;
	}
	public String getTfsi() {
		return tfsi;
	}
	public void setTfsi(String tfsi) {
		this.tfsi = tfsi;
	}
	public String getTfgu() {
		return tfgu;
	}
	public void setTfgu(String tfgu) {
		this.tfgu = tfgu;
	}
	public String getTfdong() {
		return tfdong;
	}
	public void setTfdong(String tfdong) {
		this.tfdong = tfdong;
	}
	public String getTfaddr() {
		return tfaddr;
	}
	public void setTfaddr(String tfaddr) {
		this.tfaddr=tfaddr;
	}
	public String getTftype() {
		return tftype;
	}
	public void setTftype(String tftype) {
		this.tftype = tftype;
	}
	public String getCbhyung() {
		return cbhyung;
	}
	public void setCbhyung(String cbhyung) {
		this.cbhyung=cbhyung;
	}
	public String getCbtype() {
		return cbtype;
	}
	public void setCbtype(String cbtype) {
		this.cbtype = cbtype;
	}
	public String getCbtype2() {
		return cbtype2;
	}
	public void setCbtype2(String cbtype2) {
		this.cbtype2 = cbtype2;
	}
	public int getTfprice() {
		return tfprice;
	}
	public void setTfprice(int tfprice) {
		this.tfprice = tfprice;
	}
	public String getTfwol() {
		return tfwol;
	}
	public void setTfwol(String tfwol) {
		this.tfwol = tfwol;
	}
	public String getTfname() {
		return tfname;
	}
	public void setTfname(String tfname) {
		this.tfname = tfname;
	}
	public String getTfphone() {
		return tfphone;
	}
	public void setTfphone(String tfphone) {
		this.tfphone = tfphone;
	}


	
	
	

}
