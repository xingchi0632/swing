package Swing.SeunghaLee;

import java.nio.channels.SelectionKey;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;




public class HouseDBA {
	
String url,user,pwd;
	
	public HouseDBA() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			url="jdbc:oracle:thin:@localhost:1521:xe";
			user="scott";
			pwd="TIGER";
			} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	


	public void Join(HouseBean h) {
		Connection con=null;
		
		PreparedStatement ps=null;
		try {
			con=DriverManager.getConnection(url,user,pwd);
			String sql="insert into loginmember values(LOGINMEMBER_SEQ.nextval,?,?,?,?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setString(1, h.getId());
			ps.setString(2, h.getPw());
			ps.setString(3, h.getName());
			ps.setString(4, h.getBirth());
			ps.setString(5, h.getPhone());
			ps.setString(6, h.getStorename());			
			ps.executeUpdate();
			

		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null)ps.close();
				if(con!=null)con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}

		
	}
	public int login(HouseBean h) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		PreparedStatement pstmt=null;
		String id=h.getId();
		String pw=h.getPw();
		
	try {
	con=DriverManager.getConnection(url, user, pwd);
	String sql="select pw from loginmember where id= ?";
	pstmt=con.prepareStatement(sql);
	pstmt.setString(1,id);
	rs=pstmt.executeQuery();
	
		while(rs.next()) {
			if(rs.getString(1).equals(pw)) {
				return 1;
				
			}else {
	//	h.setId(rs.getString("ID"));
	//	h.setPw(rs.getString("PW"));
				return 0;
		    }
		} 
	}catch (SQLException e) {
	e.printStackTrace();
   }
	//finally {
//	try {
//		if(rs!=null)rs.close();
//		if(st!=null)st.close();
//		if(con!=null)con.close();
//	}catch(SQLException e) {
//		e.printStackTrace();
	return-1;

	
}	
		
	
		

	
	public ArrayList<HouseBean> Viewall() {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ArrayList<HouseBean> arr=new ArrayList<>();
	try {
	con=DriverManager.getConnection(url, user, pwd);
	String sql="select * from House order by num";
	st=con.createStatement();
	rs=st.executeQuery(sql);
	while(rs.next()) {
		HouseBean h=new HouseBean();
		h.setHnum(rs.getInt("num"));
		h.setTfday(rs.getString("day"));
		h.setTfsi(rs.getString("si"));
		h.setTfgu(rs.getString("gu"));
		h.setTfdong(rs.getString("dong"));
		h.setTfaddr(rs.getString("addr"));			
		h.setTftype(rs.getInt("type"));		
		h.setCbhyung(rs.getString("type2"));
		h.setTfprice(rs.getInt("price"));
		h.setTfwol(rs.getString("wol"));
		h.setCbtype(rs.getString("builtype"));
		h.setCbtype2(rs.getString("buil"));			
		h.setTfname(rs.getString("Name"));				
		h.setTfphone(rs.getString("phone"));			
		h.setEtc(rs.getString("etc"));
		h.setCbnow(rs.getString("now"));
		arr.add(h);
	}
} catch (SQLException e) {
	e.printStackTrace();
}finally {
	try {
		if(rs!=null)rs.close();
		if(st!=null)st.close();
		if(con!=null)con.close();
	}catch(SQLException e) {
		e.printStackTrace();
	}
}
return arr;

}
	
public ArrayList<HouseBean> cbsi(){
	Connection con=null;
	Statement st=null;
	ResultSet rs=null;
	ArrayList<HouseBean> arr=new ArrayList<>();
try {
con=DriverManager.getConnection(url, user, pwd);
String sql="select si from house group by si order by si";
st=con.createStatement();
rs=st.executeQuery(sql);
while(rs.next()) {
	HouseBean h=new HouseBean();
	h.setTfsi(rs.getString("si"));
	arr.add(h);
}
} catch (SQLException e) {
e.printStackTrace();
}finally {
try {
	if(rs!=null)rs.close();
	if(st!=null)st.close();
	if(con!=null)con.close();
}catch(SQLException e) {
	e.printStackTrace();
}
}
	
	return arr;
}
	
public ArrayList<HouseBean> cbgu(String selsi){ ///////////////////////구 선택
	Connection con=null;
	Statement st=null;
	ResultSet rs=null;
	ArrayList<HouseBean> arr=new ArrayList<>();	


String si=selsi;
	
	System.out.println(si);

try {
con=DriverManager.getConnection(url, user, pwd);
String sql="select gu from house where like '%"+si+"%' group by gu";
HouseBean h=new HouseBean();	
System.out.println("select gu from house where like '%"+si+"%' group by gu");
st=con.createStatement();
rs=st.executeQuery(sql);
while(rs.next()) {
	h.setHnum(rs.getInt("num"));
	h.setTfday(rs.getString("day"));
	h.setTfsi(rs.getString("si"));
	h.setTfgu(rs.getString("gu"));
	h.setTfdong(rs.getString("dong"));
	h.setTfaddr(rs.getString("addr"));			
	h.setTftype(rs.getInt("type"));		
	h.setCbhyung(rs.getString("type2"));
	h.setTfprice(rs.getInt("price"));
	h.setTfwol(rs.getString("wol"));
	h.setCbtype(rs.getString("builtype"));
	h.setCbtype2(rs.getString("buil"));			
	h.setTfname(rs.getString("Name"));				
	h.setTfphone(rs.getString("phone"));			
	h.setEtc(rs.getString("etc"));
	h.setCbnow(rs.getString("now"));
	arr.add(h);
}
} catch (SQLException e) {
e.printStackTrace();
}finally {
try {
	if(rs!=null)rs.close();
	if(st!=null)st.close();
	if(con!=null)con.close();
}catch(SQLException e) {
	e.printStackTrace();
}
}
	
	return arr;
}

public ArrayList<HouseBean> search(String a,String b,String d,int e,String c) {/////////////////////////////////////////검색
	Connection con=null;
	Statement st=null;
	ResultSet rs=null;
	ArrayList<HouseBean> arr=new ArrayList<>();
	//System.out.println(a+ b+ c+ d+ e+"");
	
	

	String pp=Integer.toString(e);
	String jung="";
	
	
	switch(pp){
	case "0":jung="gu";break;
	case "1":jung="type desc";break;
	case "2":jung="price";break;
	}
try {
con=DriverManager.getConnection(url, user, pwd);



String sql="select * from house where si like '%"+a+"%' and builtype like '%"+b+"%' and buil like '%"+d+"%' and CONCAT(addr,etc) like '%"+c+"%' order by "+jung;
//String sql="select * from house where si like '%"+a+"%' and builtype like '%"+b+"%' and buil like '%"+d+"%' and CONCAT(addr,etc) like '%"+c+"%' order by "+jung;
//String sql="select * from house where si like '%"+a+"%' and builtype like '%"+b+"%' and buil like '%"+d+"%' and addr like '%"+c+"%' order by "+jung;
//System.out.println("select * from house where si like '%"+a+"%' and builtype like '%"+b+"%' and etc like '%"+c+"%' and buil like '%"+d+"%' order by "+jung);
st=con.createStatement();
rs=st.executeQuery(sql);
while(rs.next()) {
	HouseBean h=new HouseBean();
	h.setHnum(rs.getInt("num"));
	h.setTfday(rs.getString("day"));
	h.setTfsi(rs.getString("si"));
	h.setTfgu(rs.getString("gu"));
	h.setTfdong(rs.getString("dong"));
	h.setTfaddr(rs.getString("addr"));			
	h.setTftype(rs.getInt("type"));		
	h.setCbhyung(rs.getString("type2"));
	h.setTfprice(rs.getInt("price"));
	h.setTfwol(rs.getString("wol"));
	h.setCbtype(rs.getString("builtype"));
	h.setCbtype2(rs.getString("buil"));			
	h.setTfname(rs.getString("Name"));				
	h.setTfphone(rs.getString("phone"));			
	h.setEtc(rs.getString("etc"));
	h.setCbnow(rs.getString("now"));
	arr.add(h);
}
} catch (SQLException e1) {
e1.printStackTrace();
}finally {
try {
	if(rs!=null)rs.close();
	if(st!=null)st.close();
	if(con!=null)con.close();
}catch(SQLException e2) {
	e2.printStackTrace();
}
}
	
	return arr;
	
}


public void save() {
	Connection con=null;
	PreparedStatement ps=null;
	try {
		con=DriverManager.getConnection(url,user,pwd);
		String sql="commit";
		ps=con.prepareStatement(sql);
		ps.executeUpdate();
		JOptionPane.showMessageDialog(null,"저장되었습니다.");
	} catch (SQLException e) {
		e.printStackTrace();
	}finally {
		try {
			if(ps!=null)ps.close();
			if(con!=null)con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

public void HouseInsert(HouseBean h) {
	Connection con=null;
	PreparedStatement ps=null;
	try {
		con=DriverManager.getConnection(url,user,pwd);
		String sql="insert into house values(HOUSE_SEQ.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		ps=con.prepareStatement(sql);
		ps.setString(1, h.getTfday());
		ps.setString(2, h.getTfsi());
		ps.setString(3, h.getTfgu());
		ps.setString(4, h.getTfdong());
		ps.setString(5, h.getTfaddr());
		ps.setInt(6, h.getTftype());
		ps.setInt(7, h.getTfprice());
		ps.setString(8, h.getTfwol());		
		ps.setString(9, h.getCbtype()+"");
		ps.setString(10, h.getCbtype2()+"");
		ps.setString(11, h.getTfname());
		ps.setString(12, h.getTfphone());
		ps.setString(13, h.getEtc());		
		ps.setString(14, h.getCbhyung()+"");	
		ps.setString(15, h.getCbnow()+"");
		ps.executeUpdate();   
	} catch (SQLException e) {
		e.printStackTrace();
	}finally {
		try {
			if(ps!=null)ps.close();
			if(con!=null)con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	
}


public void HouseDelete(int row) {
	Connection con=null;
	Statement st=null;
	try {
		con=DriverManager.getConnection(url,user,pwd);
		String sql="delete from house where num="+row;
		st=con.createStatement();
		st.executeQuery(sql);
		JOptionPane.showMessageDialog(null,"삭제되었습니다.");
	} catch (SQLException e) {
			e.printStackTrace();
	}finally {
		try {
			if(st!=null)st.close();
			if(con!=null)con.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
public void HouseRE(HouseBean h,int row) {
	Connection con=null;
	Statement st=null;
	PreparedStatement ps=null;
	try {
		con=DriverManager.getConnection(url, user, pwd);
		String sql="update house set day=?,si=?,gu=?,dong=?,addr=?,type=?,price=?,wol=?, builtype=?,buil=?,name=?,phone=?,etc=?,type2=?,now=? where num=?";
		ps=con.prepareStatement(sql);
		
		ps.setString(1, h.getTfday());  //1
		//System.out.println(h.getTfday());		
		
		ps.setString(2, h.getTfsi()); //2
		//System.out.println(h.getTfsi());		
		
		ps.setString(3, h.getTfgu()); //3
		//System.out.println(h.getTfgu());
		
		ps.setString(4, h.getTfdong()); //4
		//System.out.println(h.getTfdong());
		
		ps.setString(5, h.getTfaddr());	 //5
		//System.out.println(h.getTfaddr());
		
		ps.setInt(6, h.getTftype()); //6
		//System.out.println(h.getTftype());
		

		
		ps.setInt(7, h.getTfprice()); //10
		//System.out.println(h.getTfprice());

		ps.setString(8, h.getTfwol()); //11
		//System.out.println(h.getTfwol());


		ps.setString(9, h.getCbtype()); //8
		//System.out.println(h.getCbtype());

		ps.setString(10, h.getCbtype2());  //9
		//System.out.println(h.getCbtype2());	
		
		ps.setString(11, h.getTfname()); //12
		//System.out.println(h.getTfname());
		
		ps.setString(12, h.getTfphone()); //13
		//System.out.println(h.getTfphone());
		
		ps.setString(13, h.getEtc()); //14
		//System.out.println(h.getEtc());
		

		
		ps.setString(14, h.getCbhyung());	//7
		//System.out.println(h.getCbhyung());
		
		ps.setString(15, h.getCbnow());		 //15
		//System.out.println(h.getCbnow());
		
		ps.setInt(16,row);  //16
		//System.out.println(row);
		
		ps.executeUpdate();
		JOptionPane.showMessageDialog(null,"수정되었습니다.");
	} catch (SQLException e) {
		e.printStackTrace();
	}finally {
		try {
			if(ps!=null)ps.close();
			if(con!=null)con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
}

		
	

