package Swing.SeunghaLee;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.xml.crypto.dsig.spec.HMACParameterSpec;
import javax.swing.border.BevelBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.TextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Iterator;

import java.util.Set;
import java.awt.event.ActionEvent;

public class HouseJoin extends JFrame {

	private JPanel contentPane;
	private JPanel panel;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private TextField tfJid;
	private TextField tfJpw;
	private TextField tfJpw2;
	private TextField tfJname;
	private TextField tfJbirth;
	private TextField tfJphone;
	private JButton btnOkid;
	private JButton btnOkpw;
	private JButton btnjoinin;
	HouseDBA dba=new HouseDBA();
	private JLabel lblNewLabel_9;
	private JLabel label;
	private JLabel lblNewLabel_10;
	private JLabel lblNewLabel_6;
	private TextField tfsname;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HouseJoin frame = new HouseJoin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HouseJoin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 467, 549);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		contentPane.add(getPanel(), BorderLayout.CENTER);
	}

	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBorder(new TitledBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), "\uC0AC \uC6A9 \uC790 \uB4F1 \uB85D", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panel.setLayout(null);
			panel.add(getLblNewLabel());
			panel.add(getLblNewLabel_1());
			panel.add(getLblNewLabel_2());
			panel.add(getLblNewLabel_3());
			panel.add(getLblNewLabel_4());
			panel.add(getLblNewLabel_5());
			panel.add(getTfJid());
			panel.add(getTfJpw());
			panel.add(getTfJpw2());
			panel.add(getTfJname());
			panel.add(getTfJbirth());
			panel.add(getTfJphone());
			panel.add(getBtnOkid());
			panel.add(getBtnOkpw());
			panel.add(getBtnjoinin());
			panel.add(getLblNewLabel_9());
			panel.add(getLabel());
			panel.add(getLblNewLabel_10());
			panel.add(getLblNewLabel_6());
			panel.add(getTfsname());
		}
		return panel;
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("\uC544\uC774\uB514");
			lblNewLabel.setBounds(33, 41, 57, 15);
		}
		return lblNewLabel;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("\uBE44\uBC00\uBC88\uD638");
			lblNewLabel_1.setBounds(33, 92, 57, 15);
		}
		return lblNewLabel_1;
	}
	private JLabel getLblNewLabel_2() {
		if (lblNewLabel_2 == null) {
			lblNewLabel_2 = new JLabel("\uBE44\uBC00\uBC88\uD638\uD655\uC778");
			lblNewLabel_2.setBounds(33, 147, 80, 15);
		}
		return lblNewLabel_2;
	}
	private JLabel getLblNewLabel_3() {
		if (lblNewLabel_3 == null) {
			lblNewLabel_3 = new JLabel("\uC774\uB984");
			lblNewLabel_3.setBounds(33, 199, 57, 15);
		}
		return lblNewLabel_3;
	}
	private JLabel getLblNewLabel_4() {
		if (lblNewLabel_4 == null) {
			lblNewLabel_4 = new JLabel("\uC0DD\uB144\uC6D4\uC77C");
			lblNewLabel_4.setBounds(33, 255, 57, 15);
		}
		return lblNewLabel_4;
	}
	private JLabel getLblNewLabel_5() {
		if (lblNewLabel_5 == null) {
			lblNewLabel_5 = new JLabel("\uC804\uD654\uBC88\uD638");
			lblNewLabel_5.setBounds(33, 313, 57, 15);
		}
		return lblNewLabel_5;
	}
	private TextField getTfJid() {
		if (tfJid == null) {
			tfJid = new TextField();
			tfJid.setBounds(136, 41, 152, 23);
		}
		return tfJid;
	}
	private TextField getTfJpw() {
		if (tfJpw == null) {
			tfJpw = new TextField();
			tfJpw.setBounds(136, 92, 152, 23);
		}
		return tfJpw;
	}
	private TextField getTfJpw2() {
		if (tfJpw2 == null) {
			tfJpw2 = new TextField();
			tfJpw2.setBounds(135, 139, 155, 23);
			
			
		}
		return tfJpw2;
	}
	private TextField getTfJname() {
		if (tfJname == null) {
			tfJname = new TextField();
			tfJname.setBounds(136, 191, 152, 23);
		}
		return tfJname;
	}
	private TextField getTfJbirth() {
		if (tfJbirth == null) {
			tfJbirth = new TextField();
			tfJbirth.setBounds(135, 247, 155, 23);
		}
		return tfJbirth;
	}
	private TextField getTfJphone() {
		if (tfJphone == null) {
			tfJphone = new TextField();
			tfJphone.setBounds(133, 305, 155, 23);
		}
		return tfJphone;
	}
	private JButton getBtnOkid() {
		if (btnOkid == null) {
			btnOkid = new JButton("\uC911\uBCF5\uD655\uC778");
			btnOkid.setBounds(312, 41, 97, 23);
		}
		return btnOkid;
	}
	private JButton getBtnOkpw() {
		if (btnOkpw == null) {
			btnOkpw = new JButton("\uBE44\uBC88\uD655\uC778");
			btnOkpw.setBounds(312, 143, 97, 23);
		}
		return btnOkpw;
	}
	private JButton getBtnjoinin() {
		if (btnjoinin == null) {
			btnjoinin = new JButton("사용자등록");

				btnjoinin.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
							HouseBean h=new HouseBean();
							h.setBirth(tfJbirth.getText());
							h.setId(tfJid.getText());
							h.setPw(tfJpw.getText());
							h.setName(tfJname.getText());
							h.setPhone(tfJphone.getText());
							h.setLicensenum(tfsname.getText());
							dba.Join(h);
							
							setVisible(false);
							HouseIndex I=new HouseIndex();
							I.setVisible(true);
							
							
						
					}
				});
			btnjoinin.setBounds(173, 446, 115, 23);
		}
					
		return btnjoinin;
	}

	
	private JLabel getLblNewLabel_9() {
		if (lblNewLabel_9 == null) {
			lblNewLabel_9 = new JLabel("'-'없이 숫자로만 입력하세요.");
			lblNewLabel_9.setBounds(136, 333, 187, 15);
		}
		return lblNewLabel_9;
	}
	private JLabel getLabel() {
		if (label == null) {
			label = new JLabel("6자리 숫자로만 입력하세요.");
			label.setBounds(136, 276, 187, 15);
		}
		return label;
	}
	private JLabel getLblNewLabel_10() {
		if (lblNewLabel_10 == null) {
			lblNewLabel_10 = new JLabel("비밀번호가 일치합니다.");
			lblNewLabel_10.setBounds(136, 170, 152, 15);
		}
		return lblNewLabel_10;
	}
	private JLabel getLblNewLabel_6() {
		if (lblNewLabel_6 == null) {
			lblNewLabel_6 = new JLabel("중개소명");
			lblNewLabel_6.setBounds(33, 378, 57, 15);
		}
		return lblNewLabel_6;
	}
	private TextField getTfsname() {
		if (tfsname == null) {
			tfsname = new TextField();
			tfsname.setBounds(133, 378, 155, 23);
		}
		return tfsname;
	}
}
