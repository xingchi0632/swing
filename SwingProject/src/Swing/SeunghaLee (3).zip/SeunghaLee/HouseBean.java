package Swing.SeunghaLee;

public class HouseBean {
	private int num;
	private String id;
	private String pw;
	private String name;
	private String birth;
	private String phone;
	private String tfsname;
	private int cbjun;
	private int hnum;
	private String tfday;
	private String tfsi;
	private String tfgu;
	private String tfdong;
	private String tfaddr;
	private int tftype;
	private String cbhyung;
	private String cbtype;
	private String cbtype2;
	private int tfprice;
	private String tfwol;
	private String tfname;
	private String tfphone;	
	private String etc;
	private String cbnow;
	private String cbgum;
	private String tfsangse;
	private String cb4;
	private int cbjung;
	private int chball;
	private String tfInpw;
	
	
	public String getTfInpw() {
		return tfInpw;
	}
	public void setTfInpw(String tfInpw) {
		this.tfInpw = tfInpw;
	}

	public int getChball() {
		return chball;
	}
	public void setChball(int chball) {
		this.chball = chball;
	}
	public int getCbjun() {
		return cbjun;
	}
	public void setCbjun(int cbjun) {
		this.cbjun = cbjun;
	}

	private String Jpwd;
	public String getJpwd() {
		return Jpwd;
	}
	public void setJpwd(String jpwd) {
		Jpwd = jpwd;
	}
	public String getJpwd2() {
		return Jpwd2;
	}
	public void setJpwd2(String jpwd2) {
		Jpwd2 = jpwd2;
	}

	private String Jpwd2;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getTfsname() {
		return tfsname;
	}
	public void setTfsname(String tfsname) {
		this.tfsname =tfsname;
	}

	public int getTftype() {
		return tftype;
	}
	public void setTftype(int tftype) {
		this.tftype = tftype;
	}
	
	public String getCbnow() {
		return cbnow;
	}
	public void setCbnow(String cbnow) {
		this.cbnow = cbnow;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
	public int getHnum() {
		return hnum;
	}
	public void setHnum(int hnum) {
		this.hnum = hnum;
	}
	public String getTfday() {
		return tfday;
	}
	public void setTfday(String tfday) {
		this.tfday = tfday;
	}
	public String getTfsi() {
		return tfsi;
	}
	public void setTfsi(String tfsi) {
		this.tfsi = tfsi;
	}
	public String getTfgu() {
		return tfgu;
	}
	public void setTfgu(String tfgu) {
		this.tfgu = tfgu;
	}
	public String getTfdong() {
		return tfdong;
	}
	public void setTfdong(String tfdong) {
		this.tfdong = tfdong;
	}
	public String getTfaddr() {
		return tfaddr;
	}
	public void setTfaddr(String tfaddr) {
		this.tfaddr=tfaddr;
	}
	
	public String getCbhyung() {
		return cbhyung;
	}
	public void setCbhyung(String cbhyung) {
		this.cbhyung=cbhyung;
	}
	public String getCbtype() {
		return cbtype;
	}
	public void setCbtype(String cbtype) {
		this.cbtype = cbtype;
	}
	public String getCbtype2() {
		return cbtype2;
	}
	public void setCbtype2(String cbtype2) {
		this.cbtype2 = cbtype2;
	}
	public int getTfprice() {
		return tfprice;
	}
	public void setTfprice(int tfprice) {
		this.tfprice = tfprice;
	}
	public String getTfwol() {
		return tfwol;
	}
	public void setTfwol(String tfwol) {
		this.tfwol = tfwol;
	}
	public String getTfname() {
		return tfname;
	}
	public void setTfname(String tfname) {
		this.tfname = tfname;
	}
	public String getTfphone() {
		return tfphone;
	}
	public void setTfphone(String tfphone) {
		this.tfphone = tfphone;
	}

	private String tfid;
	private String tfpw;
	
	public String getTfpw() {
		return tfpw;
	}
	public void setTfpw(String tfpw) {
		this.tfpw = tfpw;
	}
	public String getTfid() {
		return tfid;
	}
	public void setTfid(String tfid) {
		this.tfid = tfid;
	}

	public String cbsi;
	public String getCbsi() {
		return cbsi;
	}
	public void setCbsi(String cbsi) {
		this.cbsi = cbsi;
	}

	public String getCbgum() {
		return cbgum;
	}
	public void setCbgum(String cbgum) {
		this.cbgum = cbgum;
	}
	public String getTfsangse() {
		return tfsangse;
	}
	public void setTfsangse(String tfsangse) {
		this.tfsangse = tfsangse;
	}
	public String getCb4() {
		return cb4;
	}
	public void setCb4(String cb4) {
		this.cb4 = cb4;
	}

	public int getCbjung() {
		return cbjung;
	}
	public void setCbjung(int cbjung) {
		this.cbjung = cbjung;
	}


}
